"""Ten synthetic-record cases against actual n8n HTML and HTTP responses."""
from datetime import datetime, timezone
import hashlib
import html
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import time
import urllib.error
import urllib.parse
import urllib.request


def now():
    return datetime.now(timezone.utc).isoformat()


class Forms(HTMLParser):
    def __init__(self):
        super().__init__()
        self.forms = []
        self.current = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "form":
            self.current = {"action": attrs.get("action"), "method": attrs.get("method", "GET").upper(),
                            "fields": {}, "buttons": []}
            self.forms.append(self.current)
        elif tag == "input" and self.current is not None and attrs.get("name"):
            self.current["fields"][attrs["name"]] = attrs.get("value", "")
        elif tag == "button" and self.current is not None:
            self.current["buttons"].append(attrs)
        elif tag == "iframe" and attrs.get("srcdoc"):
            nested = Forms()
            nested.feed(attrs["srcdoc"])
            self.forms.extend(nested.forms)

    def handle_endtag(self, tag):
        if tag == "form":
            self.current = None


class LabClient:
    def __init__(self, n8n_url, state_url, output_dir, inputs):
        self.n8n = n8n_url
        self.state_url = state_url
        self.output = Path(output_dir)
        self.evidence = self.output / "http-evidence"
        self.evidence.mkdir(parents=True, exist_ok=True)
        self.requests = []
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self.old = inputs["original"]
        self.new = inputs["reviewed"]

    def request(self, label, url, data=None, form=False):
        assert url.startswith(self.n8n + "/") or url.startswith(self.state_url + "/")
        payload = None if data is None else (
            urllib.parse.urlencode(data).encode() if form else json.dumps(data, ensure_ascii=False).encode())
        headers = {} if data is None else {
            "Content-Type": "application/x-www-form-urlencoded" if form else "application/json"}
        started = now()
        try:
            response = self.opener.open(urllib.request.Request(url, data=payload, headers=headers), timeout=45)
        except urllib.error.HTTPError as error:
            response = error
        with response:
            body = response.read()
            status = response.code
            response_headers = dict(response.headers)
        stem = str(len(self.requests) + 1).zfill(3) + "-" + label
        (self.evidence / (stem + ".body")).write_bytes(body)
        self.requests.append({"label": label, "url": url, "method": "GET" if data is None else "POST",
                              "input": data, "started_at": started, "completed_at": now(), "status": status,
                              "headers": response_headers, "body_file": stem + ".body",
                              "body_sha256": hashlib.sha256(body).hexdigest(), "bytes": len(body)})
        (self.evidence / "requests.json").write_text(json.dumps(self.requests, ensure_ascii=False, indent=2) + "\n")
        return status, body, response_headers

    def get_forms(self, mode, doc, label):
        status, body, headers = self.request(
            label, self.n8n + "/webhook/review-" + mode + "?doc=" + urllib.parse.quote(doc))
        assert status == 200, ("form_http_status", status)
        parser = Forms()
        parser.feed(body.decode())
        assert len(parser.forms) == 2, ("expected_two_actual_forms", len(parser.forms))
        assert all(f["action"] == self.n8n + "/webhook/submit-" + mode and f["method"] == "POST"
                   for f in parser.forms)
        assert parser.forms[0]["fields"]["revision"] == parser.forms[1]["fields"]["revision"]
        assert {b.get("value") for b in parser.forms[1]["buttons"]} == {"approve", "reject"}
        assert any(k.lower() in {"content-security-policy", "content-security-policy-report-only"} for k in headers)
        return parser.forms

    def submit(self, label, actual_form, decision=None, updates=None):
        data = dict(actual_form["fields"])
        if decision:
            data["decision"] = decision
        if updates:
            data.update(updates)
        return self.request(label, actual_form["action"], data, form=True)

    def create(self, doc, past=False):
        data = {"id": doc, "payload": self.old}
        if past:
            data["expires_ms"] = int(time.time() * 1000) - 60000
        status, body, _ = self.request("seed-" + doc, self.state_url + "/lab/create", data)
        assert status == 201, ("seed_http_status", status)
        return json.loads(body)

    def state(self, doc, label):
        status, body, _ = self.request(label, self.state_url + "/lab/state?doc=" + urllib.parse.quote(doc))
        assert status == 200
        return json.loads(body)


def receipt(body):
    match = re.search(r"<pre>(.*?)</pre>", body.decode(), re.S)
    assert match, "actual HTML receipt missing"
    return json.loads(html.unescape(match.group(1)))


def payload_hash(payload):
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()


def verify_target(state, expected, writes=1):
    assert len(state["writes"]) == writes
    assert len(state["records"]) == 1
    record = state["records"][0]
    assert record["payload"] == expected
    assert record["hash"] == payload_hash(expected)
    assert state["document"]["approved_snapshot"] == expected
    assert state["document"]["approved_hash"] == record["hash"]
    assert state["document"]["target_id"] == record["id"]
    assert state["document"]["status"] == "acknowledged"
    return record["id"]


def run_case(client, mode, kind):
    doc = "case-" + mode + "-" + kind
    out = {"mode": mode, "case": kind, "document_id": doc, "started_at": now()}
    try:
        client.create(doc, past=kind == "expired")
        first = client.get_forms(mode, doc, doc + "-page-r1")
        if kind == "normal":
            code, body, _ = client.submit(doc + "-save", first[0], updates=client.new)
            assert code == 200 and receipt(body)["outcome"] == "draft_saved"
            current = client.get_forms(mode, doc, doc + "-page-r2")
            assert current[1]["fields"]["revision"] == "2"
            code, body, _ = client.submit(doc + "-approve", current[1], "approve")
            assert code == 200 and receipt(body)["outcome"] == "delivered"
            actual = client.state(doc, doc + "-state")
            target = verify_target(actual, client.new)
            assert receipt(body)["target_id"] == target
            out.update(http_status=code, outcome="delivered", writes=1, final_state=actual)
        elif kind == "reject":
            code, body, _ = client.submit(doc + "-reject", first[1], "reject")
            assert code == 200 and receipt(body)["outcome"] == "rejected"
            actual = client.state(doc, doc + "-state")
            assert actual["document"]["status"] == "rejected" and not actual["records"] and not actual["writes"]
            out.update(http_status=code, outcome="rejected", writes=0, final_state=actual)
        elif kind == "stale":
            second = client.get_forms(mode, doc, doc + "-second-page-r1")
            assert first[1]["fields"]["revision"] == second[1]["fields"]["revision"] == "1"
            code, body, _ = client.submit(doc + "-new-tab-save", second[0], updates=client.new)
            assert code == 200 and receipt(body)["outcome"] == "draft_saved"
            saved = client.state(doc, doc + "-saved-state")
            assert saved["document"]["revision"] == 2 and saved["document"]["payload"] == client.new and not saved["writes"]
            code, body, _ = client.submit(doc + "-old-tab-approve", first[1], "approve")
            old_receipt = receipt(body)
            after_old = client.state(doc, doc + "-after-old-submit")
            out.update(old_submit_http_status=code, old_submit_outcome=old_receipt["outcome"], after_old_submit=after_old)
            if mode == "guarded":
                assert code == 409 and old_receipt["outcome"] == "stale_revision"
                assert not after_old["writes"] and not after_old["records"]
                assert after_old["document"]["payload"] == client.new and after_old["document"]["revision"] == 2
                current = client.get_forms(mode, doc, doc + "-current-page-r2")
                code, body, _ = client.submit(doc + "-current-approve", current[1], "approve")
                assert code == 200 and receipt(body)["outcome"] == "delivered"
                actual = client.state(doc, doc + "-final-state")
                assert receipt(body)["target_id"] == verify_target(actual, client.new)
                out.update(outcome="delivered_current_after_stale_rejected", writes=1, final_state=actual)
            else:
                assert code == 200 and old_receipt["outcome"] == "delivered"
                verify_target(after_old, client.old)
                assert after_old["document"]["payload"] == client.new
                assert after_old["records"][0]["payload"] != after_old["document"]["payload"]
                out.update(outcome="stale_snapshot_delivered_by_baseline", writes=1, final_state=after_old)
        elif kind == "expired":
            code, body, _ = client.submit(doc + "-expired-approve", first[1], "approve")
            result = receipt(body)
            actual = client.state(doc, doc + "-state")
            if mode == "guarded":
                assert code == 410 and result["outcome"] == "expired"
                assert actual["document"]["status"] == "expired" and not actual["writes"] and not actual["records"]
                writes = 0
            else:
                assert code == 200 and result["outcome"] == "delivered"
                verify_target(actual, client.old)
                writes = 1
            out.update(http_status=code, outcome=result["outcome"], writes=writes, final_state=actual)
        elif kind == "duplicate":
            code, body, _ = client.submit(doc + "-first-approve", first[1], "approve")
            assert code == 200 and receipt(body)["outcome"] == "delivered"
            target = verify_target(client.state(doc, doc + "-after-first"), client.old)
            code, body, _ = client.submit(doc + "-same-approval-again", first[1], "approve")
            result = receipt(body)
            actual = client.state(doc, doc + "-after-second")
            if mode == "guarded":
                assert code == 200 and result["outcome"] == "already_delivered"
                verify_target(actual, client.old, writes=1)
                writes = 1
            else:
                assert code == 200 and result["outcome"] == "delivered"
                verify_target(actual, client.old, writes=2)
                writes = 2
            assert result["target_id"] == target
            out.update(http_status=code, outcome=result["outcome"], writes=writes, final_state=actual)
        else:
            raise AssertionError("unknown case")
        out["all_passed"] = True
    except Exception as error:
        out.update(all_passed=False, error=repr(error))
    out["completed_at"] = now()
    (client.output / (doc + ".json")).write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
    return out


def run_suite(client):
    results = [run_case(client, mode, kind) for mode in ["baseline", "guarded"]
               for kind in ["normal", "reject", "stale", "expired", "duplicate"]]
    summary = {"scope": "Actual n8n Webhook/HTTP Request/If/Respond plus application guard and local CRM; synthetic records.",
               "all_passed": all(r["all_passed"] for r in results), "case_count": len(results),
               "request_count": len(client.requests), "results": results}
    (client.output / "results.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    return summary
