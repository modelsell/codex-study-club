# n8n 资料校对与版本交付实验

这个包用一条合成资料记录，比较两个普通工作流：旧页面提交批准时，基线会交付旧字段；带版本守卫的对照先拒绝旧页，再由新页批准交付新字段。最终判断依据是本地 CRM 的真实记录和写入次数，表单成功文案只是其中一步。

资料、审核选择和 CRM 都是实验输入；没有 OCR、模型调用、真人审批或生产客户数据。实际编排入口是 **Webhook → HTTP Request → If → Respond to Webhook**。版本、业务期限、冻结快照和确认逻辑由 `review-services.mjs` 中的应用服务实现；这不是 n8n 原生 Form/Wait 的完整实测，也不是可直接部署的审批系统。

## 固定环境与文件

需要 Python 3.9+（仅标准库）、PATH 中可运行的 Docker，以及可启动 Linux arm64 容器的环境。本包在本机 Unix socket 的 Docker Desktop/Linux aarch64 引擎下验收；运行前用 `docker context show` 和 `docker context inspect` 核对当前端点。远程 ssh/tcp 上下文不在本次范围，runner不会替你切换上下文，应先由你确认本机环境再运行。固定正式镜像为：

```text
docker.n8n.io/n8nio/n8n@sha256:a1a9955a4a9e5dd9fa65a62f59e0751351b45b9e5cd2c17e6e330a8d0026cad8
```

该官方 arm64 发行物为 n8n **2.49.6**；原研究实例读回 Node **26.13.0**，runner 会在每次新实例中另存实际版本。镜像缺失时仅拉取这个精确 digest。主机不需要安装 Node 或 n8n；x86 模拟运行和其他镜像未验证。

2026-11-26，从ZIP解压件启动的全新专用实例实际读回相同版本，十组全部通过。测试驱动共记录57次HTTP请求，含合成记录初始化、页面/提交和独立状态回读；不是57次n8n执行，也不含全部内部节点HTTP。结束后的专用容器、网络和代理端口清理通过。这些请求全部使用合成资料，不是本站独立读者任务成果。

| 文件 | 用途 |
| --- | --- |
| `workflows.json` | baseline、guarded 两条普通工作流，共18节点，不含凭据 |
| `review-services.mjs` | 校对页、SQLite 状态/冻结快照/确认及本地 CRM |
| `http-bridge.mjs`、`loopback_bridge.py` | 将宿主127.0.0.1上的真实 HTTP 请求转入本实例容器，保留响应/CSP |
| `run_lab.py`、`start-server.sh` | 新建、导入、发布、运行和精确清理本次资源 |
| `lab_cases.py`、`synthetic-inputs.json` | 十组断言与两份合成字段 |
| `MANIFEST.sha256` | 包内文件指纹 |

## 一次完整复现

解压 ZIP，进入包含本说明的目录，运行：

```bash
python3 run_lab.py
```

runner 新建随机命名的容器、专用 `--internal` 网络和一个包目录以外的临时实例目录；不复用既有 n8n 数据、用户或端口，不使用全局清理。容器不发布端口，宿主代理只绑定127.0.0.1。工作流节点在同一容器内通过 HTTP 调用实验服务；桥不会伪造 n8n 的表单或业务响应。它只实现本地普通 HTTP/REST，不实现 WebSocket 或编辑器的流式推送。

新 owner 和加密随机值仅在运行时生成，写入实例目录下权限为0600的私有文件，不打印、不放进这个包。容器仅挂载四个只读实验文件及本次专用的 state/runtime/logs 子目录；没有挂载宿主 Docker socket、用户目录或其他项目数据。实验端点没有生产身份/权限模型，只应使用随包合成字段。

启动后会建立新 owner，使用官方 CLI 导入并 publish 两条工作流，再重启自己的容器使生产 Webhook 生效。随后逐组读取实际 HTML 表单、提交字段，并独立 GET 目标状态。普通执行结束会停止并移除自己的容器/网络、关闭自己的代理；实例目录保留证据。若指定目录，必须是包目录以外尚不存在的专用目录：

```bash
python3 run_lab.py --state-dir ../my-private-run
```

相对路径按当前工作目录计算；这个示例将私有实例放在包的上一级。

## 十组应看到什么

正常组先将 `Synthetic Old Draft / old@example.invalid / 100` 保存为 `Synthetic Reviewed Record / reviewed@example.invalid / 1250.5`，再打开新页批准。旧页面组实际保留两次 GET 得到的 r1 表单，由第二份先保存 r2，再提交第一份的批准字段。

| 场景 | baseline | guarded |
| --- | --- | --- |
| 正常保存后批准 | r2交付，目标与冻结快照一致，写1次 | 同左 |
| 拒绝 | rejected，目标写0次 | 同左 |
| 旧r1页面在r2保存后批准 | 200/delivered，但CRM收到旧r1；review里的当前字段仍r2，写1次 | 409/stale_revision，先写0次；随后新r2页批准，交付新字段，累计写1次 |
| 已过业务期限后批准 | 200/delivered，写1次 | 410/expired，写0次 |
| 同一批准再提交一次 | 再次delivered，写2次，最终仍1条CRM记录（upsert） | already_delivered，总写1次 |

“通过”表示上述预期现象和字节/字段/哈希断言符合，包括故意缺少守卫的基线现象；不表示 baseline 适合实际业务。两个模式各五组，总计十组，没有额外故障变体。

## 保留真实页面，手动走双页步骤

```bash
python3 run_lab.py --keep
```

自动十组通过后，会额外建立 `ui-baseline`、`ui-guarded` 两条新合成记录，打印完整的 review 与只读 state URL，并写入实例目录的 `ui-links.json`。进程保持运行，按 Ctrl-C 清理本次资源。只做手动页面、不执行十组可用 `--ui-only`；这不代表十组已通过。

以 guarded 链接为例：

1. 在两个独立标签页 A/B 打开同一个完整 review URL，确认都显示版本1。
2. B 修改公司、邮箱和金额，点击“保存修正，不交付”，再点“打开当前版本”，确认版本2和新字段。此时先读 state URL，应无目标写入。
3. A 保留原页，点击“批准已保存版本并交付”，应显示 stale_revision；另开 state URL，确认当前字段仍是新版本，records/writes仍空。
4. 回到新版本2页面批准，再独立读取 state URL。`approved_snapshot`、目标记录 payload/hash、`target_id` 应对应新字段，writes为1。

baseline 可按相同步骤观察旧字段进入 CRM；不要拿旁边 guarded 的正确记录替代本次 baseline 的目标。需要查看 n8n 编辑器时，可从实例目录的 `private-owner.json` 手动取新账号；不要把该文件或会话 Cookie 放入公共复现材料。直接校对页不要求编辑器登录。

## 读回证据与收尾

运行会输出专用实例目录。其中 `results/results.json` 是十组结果；每组文件包含独立目标回读。`results/http-evidence/requests.json` 及对应 body 保存合成请求、实际 HTTP 状态/CSP和响应指纹；owner设置不进入这组请求证据。`versions.json`、`image.json`、CLI日志记录实际发行物、导入和发布；`cleanup.json` 记录本次容器/网络不存在及宿主端口关闭。私有 owner、env 和运行数据库保留在这个新实例目录内，不能随成果公开。

若终端被强制结束，先确认原 runner 已停止，再用它写下的实例目录清理；命令只接受该随机 lab ID/容器ID/专用标签，不按名称模糊匹配，也不 prune：

```bash
python3 run_lab.py --cleanup ../my-private-run
```

## 机制、代价与未验证范围

guarded 的 SQLite `BEGIN IMMEDIATE` 在同一事务中检查 pending、服务端当前 revision 和数据库时间，再冻结 approved_snapshot/hash/request_key。下游写入使用冻结 claim；确认时重新读取服务端冻结记录，与转发的 claim、独立 GET 的目标 payload/hash/key逐项比较，成功才从 claimed进入acknowledged。DOM隐藏字段仍是请求输入，不能充当权限。所有能保存修正的实际入口都必须遵守相同的版本推进规则。

期限检查位于 **DB接受claim时**，不保证目标写入完成时仍未过期。当前 CRM 的固定记录ID、请求键与 upsert 只覆盖这个单记录演示；拒绝后重新开启、跨修订版重复交付、崩溃后的自动恢复、目标端不确定写入、并发/跨服务事务与任意外部CRM均未验证。没有真实用户权限、OCR、模型、Cloud、外部邮箱/Slack或生产网络交付。需要自行维护状态和回执，不能从这十组推导生产 exactly-once 或 n8n 原生审批保证。

## 当日来源与版本边界

2026-11-26 核对固定 [n8n2.49.6 Release](https://github.com/n8n-io/n8n/releases/tag/n8n%402.49.6)，tag `5fae94bb8d37827d1c11b7d748b92343477459c1`。入口比较参考官方 [Webhook](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.webhook/)、[Respond to Webhook](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.respondtowebhook/)、[Wait](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.wait/)及[CLI](https://docs.n8n.io/hosting/cli-commands/)资料；动态文档首发日期未知。这个包只执行自身JSON中的Webhook路径，不把资料阅读或新版表达式条目当作Form/Wait审批修复。
