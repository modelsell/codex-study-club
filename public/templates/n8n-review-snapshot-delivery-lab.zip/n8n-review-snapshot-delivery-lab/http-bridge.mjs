import http from 'node:http';
let input = '';
for await (const chunk of process.stdin) input += chunk;
const request = JSON.parse(input);
if (![5678,18082].includes(request.port)) throw new Error('fixed lab ports only');
const headers = {...request.headers, 'accept-encoding':'identity'};
delete headers['connection'];
delete headers['transfer-encoding'];
const body = Buffer.from(request.body || '', 'base64');
headers['content-length'] = body.length;
const output = await new Promise((resolve,reject)=>{
  const req=http.request({host:'127.0.0.1',port:request.port,path:request.path,method:request.method,headers},res=>{
    const chunks=[];res.on('data',c=>chunks.push(c));res.on('end',()=>resolve({status:res.statusCode,headers:res.rawHeaders,body:Buffer.concat(chunks).toString('base64')}));
  });
  req.setTimeout(25000,()=>req.destroy(new Error('lab HTTP timeout')));
  req.on('error',reject);req.end(body);
});
process.stdout.write(JSON.stringify(output));
