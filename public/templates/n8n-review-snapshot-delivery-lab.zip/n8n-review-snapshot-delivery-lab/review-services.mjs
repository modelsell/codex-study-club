import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { createHash, randomUUID } from 'node:crypto';
import { mkdirSync, appendFileSync } from 'node:fs';

const stateDir = process.env.LAB_STATE_DIR || '/lab/state';
const publicUrl = process.env.LAB_N8N_PUBLIC_URL;
if (!publicUrl || !/^http:\/\/127\.0\.0\.1:\d+\/$/.test(publicUrl)) throw new Error('loopback public URL required');
mkdirSync(stateDir, { recursive: true });
const review = new DatabaseSync(stateDir + '/review.sqlite');
const crm = new DatabaseSync(stateDir + '/crm.sqlite');
review.exec('PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS documents(id TEXT PRIMARY KEY,revision INTEGER NOT NULL,payload TEXT NOT NULL,status TEXT NOT NULL,expires_ms INTEGER NOT NULL,approved_revision INTEGER,approved_snapshot TEXT,approved_hash TEXT,request_key TEXT,target_id TEXT); CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY,document_id TEXT,kind TEXT,body TEXT,at_ms INTEGER);');
crm.exec('PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY,document_id TEXT,payload TEXT,hash TEXT,request_key TEXT UNIQUE); CREATE TABLE IF NOT EXISTS writes(seq INTEGER PRIMARY KEY,record_id TEXT,document_id TEXT,payload TEXT,request_key TEXT,at_ms INTEGER);');
const dbNow = () => review.prepare("SELECT CAST(unixepoch('subsec')*1000 AS INTEGER) AS now_ms").get().now_ms;
const hash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const esc = v => String(v ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
const normalize = input => {
  const out = { company_name: String(input.company_name || '').trim(), contact_email: String(input.contact_email || '').trim(), invoice_total: Number(input.invoice_total) };
  if (!out.company_name || out.company_name.length > 120 || !/^[^@\s]+@[^@\s]+$/.test(out.contact_email) || !Number.isFinite(out.invoice_total) || out.invoice_total < 0) throw new Error('invalid synthetic record fields');
  return out;
};
const getDoc = id => {
  const row = review.prepare('SELECT * FROM documents WHERE id=?').get(id);
  if (!row) return null;
  return { ...row, payload: JSON.parse(row.payload), approved_snapshot: row.approved_snapshot ? JSON.parse(row.approved_snapshot) : null };
};
const log = (id, kind, body) => review.prepare('INSERT INTO events(document_id,kind,body,at_ms) VALUES(?,?,?,?)').run(id,kind,JSON.stringify(body),dbNow());
const page = (title, body) => '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + esc(title) + '</title><body><main><h1>' + esc(title) + '</h1>' + body + '</main></body></html>';
const reviewLink = (id, mode) => publicUrl + 'webhook/review-' + mode + '?doc=' + encodeURIComponent(id);
const summary = doc => '<dl><dt>记录</dt><dd>' + esc(doc.id) + '</dd><dt>版本</dt><dd>' + doc.revision + '</dd><dt>状态</dt><dd>' + esc(doc.status) + '</dd><dt>业务截止（DB claim前检查）</dt><dd>' + esc(new Date(doc.expires_ms).toISOString()) + '</dd><dt>公司</dt><dd>' + esc(doc.payload.company_name) + '</dd><dt>邮箱</dt><dd>' + esc(doc.payload.contact_email) + '</dd><dt>金额</dt><dd>' + doc.payload.invoice_total + '</dd></dl>';
const hidden = (name, value) => '<input type="hidden" name="' + name + '" value="' + esc(value) + '">';
function render(doc, mode) {
  const action = publicUrl + 'webhook/submit-' + mode;
  const common = hidden('document_id',doc.id) + hidden('revision',doc.revision);
  const edit = '<h2>1. 保存修正（不交付）</h2><form method="POST" action="' + action + '">' + common + hidden('decision','save') +
    '<p><label>公司 <input name="company_name" required value="' + esc(doc.payload.company_name) + '"></label></p>' +
    '<p><label>邮箱 <input name="contact_email" required value="' + esc(doc.payload.contact_email) + '"></label></p>' +
    '<p><label>金额 <input name="invoice_total" type="number" min="0" step="0.01" required value="' + doc.payload.invoice_total + '"></label></p>' +
    '<button type="submit">保存修正，不交付</button></form>';
  const approval = '<h2>2. 批准已保存的这一版</h2><p>这是只读快照。修改上方字段后，先保存并打开新版页面再批准。隐藏字段不构成服务端权限。</p>' + summary(doc) +
    '<form method="POST" action="' + action + '">' + common + hidden('company_name',doc.payload.company_name) + hidden('contact_email',doc.payload.contact_email) + hidden('invoice_total',doc.payload.invoice_total) +
    '<button name="decision" value="approve" type="submit">批准已保存版本并交付</button> <button name="decision" value="reject" type="submit">拒绝，零写入</button></form>';
  return page('资料校对实验 · ' + mode, '<p>本地合成资料；自建页面 + n8n 编排 + 实验 DB 守卫。不是 n8n 原生审批保证。</p>' + edit + approval);
}
function result(id, mode, outcome, code, detail, extra={}) {
  const receipt = { document_id:id, outcome, ...extra };
  return { action:'reply', status_code:code, receipt, html:page('处理结果 · ' + outcome, '<p id="outcome">' + esc(detail) + '</p><pre>' + esc(JSON.stringify(receipt,null,2)) + '</pre><p><a href="' + reviewLink(id,mode) + '">打开当前版本</a></p>') };
}
function claim(body) {
  const mode = body.mode === 'baseline' ? 'baseline' : 'guarded';
  const id = String(body.document_id || '');
  const revision = Number(body.revision);
  const decision = String(body.decision || '');
  if (!/^[A-Za-z0-9_-]{1,80}$/.test(id) || !Number.isInteger(revision) || !['save','approve','reject'].includes(decision)) return result(id,mode,'invalid_input',400,'无效实验输入，未写入目标。');
  review.exec('BEGIN IMMEDIATE');
  try {
    const doc = getDoc(id);
    if (!doc) { review.exec('COMMIT'); return result(id,mode,'missing',404,'记录不存在。'); }
    if (mode === 'guarded') {
      if (doc.status === 'acknowledged' && decision === 'approve' && revision === doc.approved_revision) {
        log(id,'duplicate_approval',{revision,target_id:doc.target_id}); review.exec('COMMIT');
        return result(id,mode,'already_delivered',200,'相同批准已交付；未再次写入。',{target_id:doc.target_id,snapshot_hash:doc.approved_hash});
      }
      if (doc.status !== 'pending') {
        log(id,'state_rejected',{status:doc.status,revision}); review.exec('COMMIT');
        return result(id,mode,'state_conflict',409,'记录已不处于可审状态；未写入目标。',{current_status:doc.status});
      }
      if (revision !== doc.revision) {
        log(id,'stale_revision',{submitted:revision,current:doc.revision}); review.exec('COMMIT');
        return result(id,mode,'stale_revision',409,'旧页面版本已失效；未覆盖新修正，也未写入目标。',{submitted_revision:revision,current_revision:doc.revision});
      }
      if (dbNow() >= doc.expires_ms) {
        review.prepare("UPDATE documents SET status='expired' WHERE id=?").run(id); log(id,'expired',{revision,expires_ms:doc.expires_ms}); review.exec('COMMIT');
        return result(id,mode,'expired',410,'已过业务截止；未写入目标。');
      }
    }
    if (decision === 'save') {
      const payload = normalize(body);
      review.prepare('UPDATE documents SET revision=revision+1,payload=? WHERE id=?').run(JSON.stringify(payload),id);
      const next = getDoc(id);log(id,'draft_saved',{from_revision:revision,new_revision:next.revision,payload});review.exec('COMMIT');
      return result(id,mode,'draft_saved',200,'修正已保存，尚未批准或交付。请打开当前版本再批准。',{current_revision:next.revision,snapshot_hash:hash(payload)});
    }
    if (decision === 'reject') {
      review.prepare("UPDATE documents SET status='rejected' WHERE id=?").run(id);log(id,'rejected',{revision});review.exec('COMMIT');
      return result(id,mode,'rejected',200,'已拒绝，目标写入为零。');
    }
    const snapshot = mode === 'guarded' ? doc.payload : normalize(body);
    const snapshotHash = hash(snapshot);
    const requestKey = mode === 'guarded' ? 'approve:' + id + ':r' + doc.revision : 'baseline:' + randomUUID();
    const approvedRevision = mode === 'guarded' ? doc.revision : revision;
    review.prepare("UPDATE documents SET status='claimed',approved_revision=?,approved_snapshot=?,approved_hash=?,request_key=?,target_id=NULL WHERE id=?").run(approvedRevision,JSON.stringify(snapshot),snapshotHash,requestKey,id);
    const frozen = { document_id:id,approved_revision:approvedRevision,snapshot,snapshot_hash:snapshotHash,request_key:requestKey,mode };
    log(id,'claimed',frozen);review.exec('COMMIT');return { action:'write',status_code:200,claim:frozen };
  } catch (e) { review.exec('ROLLBACK');return result(id,mode,'invalid_input',400,String(e.message)); }
}
function acknowledge(body) {
  const c = body.claim, target = body.target;
  const id = String(c?.document_id || '');
  const mode = c?.mode === 'baseline' ? 'baseline' : 'guarded';
  if (!c || !target) return result(id,mode,'unconfirmed',502,'未取得完整目标回读，不能确认交付。',{reason:'missing_claim_or_target'});
  review.exec('BEGIN IMMEDIATE');
  try {
    const doc = getDoc(id);
    const reject = (reason,detail,code=502) => {
      if (doc) log(id,'ack_rejected',{reason,request_key:c.request_key,target_id:target.target_id});
      review.exec('COMMIT');
      return result(id,mode,'unconfirmed',code,detail,{reason});
    };
    if (!doc || doc.status !== 'claimed' || !doc.approved_snapshot) return reject('state_conflict','服务端没有相应的待确认批准快照。',409);
    const canonicalHash = hash(doc.approved_snapshot);
    if (canonicalHash !== doc.approved_hash) return reject('stored_snapshot_mismatch','服务端冻结快照校验失败，不能确认交付。');
    const claimMatches = c.document_id === doc.id &&
      c.request_key === doc.request_key &&
      c.approved_revision === doc.approved_revision &&
      c.snapshot_hash === doc.approved_hash &&
      hash(c.snapshot) === doc.approved_hash;
    if (!claimMatches) return reject('claim_mismatch','流程转发的 claim 与服务端已批准快照不一致；目标可能已写入，尚未确认，需核对。');
    const targetMatches = target.document_id === doc.id &&
      target.request_key === doc.request_key &&
      target.snapshot_hash === doc.approved_hash &&
      hash(target.payload) === doc.approved_hash &&
      typeof target.target_id === 'string' && target.target_id.length > 0;
    if (!targetMatches) return reject('target_mismatch','目标回读与服务端已批准快照不一致；尚未确认，需核对。');
    const update = review.prepare("UPDATE documents SET status='acknowledged',target_id=? WHERE id=? AND status='claimed' AND request_key=? AND approved_revision=? AND approved_hash=? AND approved_snapshot=?").run(target.target_id,doc.id,doc.request_key,doc.approved_revision,doc.approved_hash,JSON.stringify(doc.approved_snapshot));
    if (!update.changes) return reject('ack_conflict','批准状态已变化，尚未确认交付。',409);
    log(id,'acknowledged',{target_id:target.target_id,snapshot_hash:doc.approved_hash,approved_revision:doc.approved_revision});
    review.exec('COMMIT');
    return result(id,mode,'delivered',200,'已回读目标记录，并对照服务端冻结的批准快照确认一致。',{target_id:target.target_id,snapshot_hash:doc.approved_hash,approved_revision:doc.approved_revision});
  } catch (e) {
    try { review.exec('ROLLBACK'); } catch {}
    return result(id,mode,'unconfirmed',502,'确认步骤失败，目标可能已写入，不能报告已交付。',{reason:'ack_validation_error'});
  }
}
const jsonResponse = (res, code, body) => {res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(body));};
async function readBody(req) {let text='';for await (const chunk of req){text+=chunk;if(text.length>65536)throw new Error('body too large');}return text ? JSON.parse(text) : {};}
const inspect = id => ({document:getDoc(id),events:review.prepare('SELECT * FROM events WHERE document_id=? ORDER BY seq').all(id).map(r=>({...r,body:JSON.parse(r.body)})),records:crm.prepare('SELECT * FROM records WHERE document_id=?').all(id).map(r=>({...r,payload:JSON.parse(r.payload)})),writes:crm.prepare('SELECT * FROM writes WHERE document_id=? ORDER BY seq').all(id).map(r=>({...r,payload:JSON.parse(r.payload)}))});
function createDocument(input) {
  if (!/^[A-Za-z0-9_-]{1,80}$/.test(input.id || '')) throw new Error('invalid document id');
  const payload=normalize(input.payload);const expires=Number.isFinite(input.expires_ms)?input.expires_ms:dbNow()+3600000;
  review.prepare('INSERT INTO documents(id,revision,payload,status,expires_ms) VALUES(?,1,?,?,?)').run(input.id,JSON.stringify(payload),'pending',expires);
  log(input.id,'seeded',{payload,expires_ms:expires});return getDoc(input.id);
}
const reviewServer=http.createServer(async(req,res)=>{
  const u=new URL(req.url,'http://127.0.0.1');
  try {
    if(req.method==='GET' && u.pathname==='/health')return jsonResponse(res,200,{ok:true,service:'review-state',db_now_ms:dbNow()});
    if(req.method==='GET' && u.pathname==='/render'){
      const doc=getDoc(u.searchParams.get('doc'));if(!doc)return jsonResponse(res,404,{html:page('不存在','<p>记录不存在。</p>'),status_code:404});
      const mode=u.searchParams.get('mode')==='baseline'?'baseline':'guarded';return jsonResponse(res,200,{html:render(doc,mode),status_code:200,document_id:doc.id,revision:doc.revision});
    }
    if(req.method==='POST' && u.pathname==='/claim')return jsonResponse(res,200,claim(await readBody(req)));
    if(req.method==='POST' && u.pathname==='/ack')return jsonResponse(res,200,acknowledge(await readBody(req)));
    jsonResponse(res,404,{error:'not_found'});
  }catch(e){jsonResponse(res,500,{error:String(e.message)});}
});
const crmServer=http.createServer(async(req,res)=>{
  const u=new URL(req.url,'http://127.0.0.1');
  try {
    if(req.method==='GET' && u.pathname==='/health')return jsonResponse(res,200,{ok:true,service:'fake-crm',db_now_ms:dbNow()});
    if(req.method==='POST' && u.pathname==='/lab/create')return jsonResponse(res,201,createDocument(await readBody(req)));
    if(req.method==='GET' && u.pathname==='/lab/state')return jsonResponse(res,200,inspect(u.searchParams.get('doc')));
    if(req.method==='POST' && u.pathname==='/records'){
      const c=await readBody(req);const payload=normalize(c.snapshot);if(hash(payload)!==c.snapshot_hash)throw new Error('snapshot hash mismatch');
      const existing=crm.prepare('SELECT * FROM records WHERE request_key=?').get(c.request_key);
      if(existing)return jsonResponse(res,200,{target_id:existing.id,document_id:existing.document_id,snapshot_hash:existing.hash,request_key:existing.request_key,idempotent_replay:true});
      const targetId='crm-'+c.document_id;
      crm.exec('BEGIN IMMEDIATE');
      try{
        crm.prepare('INSERT INTO records(id,document_id,payload,hash,request_key) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,hash=excluded.hash,request_key=excluded.request_key').run(targetId,c.document_id,JSON.stringify(payload),c.snapshot_hash,c.request_key);
        crm.prepare('INSERT INTO writes(record_id,document_id,payload,request_key,at_ms) VALUES(?,?,?,?,?)').run(targetId,c.document_id,JSON.stringify(payload),c.request_key,dbNow());crm.exec('COMMIT');
      }catch(e){crm.exec('ROLLBACK');throw e;}
      return jsonResponse(res,201,{target_id:targetId,document_id:c.document_id,snapshot_hash:c.snapshot_hash,request_key:c.request_key});
    }
    if(req.method==='GET' && u.pathname.startsWith('/records/')){
      const row=crm.prepare('SELECT * FROM records WHERE id=?').get(decodeURIComponent(u.pathname.slice(9)));
      if(!row)return jsonResponse(res,404,{error:'target_missing'});return jsonResponse(res,200,{target_id:row.id,document_id:row.document_id,payload:JSON.parse(row.payload),snapshot_hash:row.hash,request_key:row.request_key});
    }
    jsonResponse(res,404,{error:'not_found'});
  }catch(e){jsonResponse(res,500,{error:String(e.message)});}
});
reviewServer.listen(18081,'0.0.0.0');crmServer.listen(18082,'0.0.0.0');
console.log(JSON.stringify({event:'lab_services_ready',review_port:18081,crm_port:18082,public_url:publicUrl,node:process.version,deadline_semantics:'database claim time; not target-write completion time'}));
process.on('SIGTERM',()=>{reviewServer.close();crmServer.close();setTimeout(()=>process.exit(0),100).unref();});
