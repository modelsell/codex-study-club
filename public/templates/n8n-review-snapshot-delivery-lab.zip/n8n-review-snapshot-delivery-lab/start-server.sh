#!/bin/sh
set -eu
node /lab/review-services.mjs > /lab/logs/services.stdout 2> /lab/logs/services.stderr &
service_pid=$!
n8n start > /lab/logs/n8n.stdout 2> /lab/logs/n8n.stderr &
n8n_pid=$!
stop_children() {
  kill -TERM "$n8n_pid" "$service_pid" 2>/dev/null || true
  wait "$n8n_pid" 2>/dev/null || true
  wait "$service_pid" 2>/dev/null || true
}
trap 'stop_children; exit 0' TERM INT
status=0
wait "$n8n_pid" || status=$?
kill -TERM "$service_pid" 2>/dev/null || true
wait "$service_pid" 2>/dev/null || true
exit "$status"
