#!/usr/bin/env python3
"""Start an isolated, synthetic n8n review lab; run ten cases; clean only its resources."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

from lab_cases import LabClient, run_suite
from loopback_bridge import LoopbackBridge

IMAGE = "docker.n8n.io/n8nio/n8n@sha256:a1a9955a4a9e5dd9fa65a62f59e0751351b45b9e5cd2c17e6e330a8d0026cad8"
LABEL = "org.agent-fieldnotes.review-lab"
PACKAGE = Path(__file__).resolve().parent
HTTP = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def now():
    return datetime.now(timezone.utc).isoformat()


def private_json(path, data):
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def call_json(url, data=None, timeout=10):
    payload = None if data is None else json.dumps(data).encode()
    headers = {} if data is None else {"Content-Type": "application/json"}
    with HTTP.open(urllib.request.Request(url, data=payload, headers=headers), timeout=timeout) as response:
        body = response.read()
        return response.status, json.loads(body) if body else None


def command(docker, args, instance, name, timeout=120, allow_failure=False):
    process = subprocess.run([docker, *args], capture_output=True, timeout=timeout)
    (instance / "logs" / (name + ".stdout")).write_bytes(process.stdout)
    (instance / "logs" / (name + ".stderr")).write_bytes(process.stderr)
    private_json(instance / "logs" / (name + ".json"),
                 {"completed_at": now(), "command": ["docker", *args], "exit_code": process.returncode})
    if process.returncode and not allow_failure:
        raise RuntimeError(name + " failed; see private instance logs")
    return process


def inspect_resource(docker, kind, name):
    if kind == "container":
        template = "{{json .Id}}\n{{json .Config.Labels}}\n{{json .State.Status}}"
    else:
        template = "{{json .Id}}\n{{json .Labels}}\n{{json .Internal}}"
    process = subprocess.run([docker, kind, "inspect", "--format", template, name], capture_output=True, text=True, timeout=20)
    if process.returncode:
        error = process.stderr.lower()
        if "no such" in error or "not found" in error:
            return None
        raise RuntimeError("Could not inspect this lab's " + kind)
    rows = [json.loads(line) for line in process.stdout.splitlines()]
    return {"id": rows[0], "labels": rows[1] or {}, "state_or_internal": rows[2]}


def port_open(port):
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.3):
            return True
    except OSError:
        return False


def cleanup(docker, instance, state, bridge=None):
    result = {"started_at": now(), "lab_id": state["lab_id"], "actions": []}
    lab_id = state["lab_id"]
    assert lab_id.startswith("n8n-review-lab-") and state["container_name"] == lab_id + "-n8n"
    assert state["network_name"] == lab_id + "-internal"
    if bridge is not None:
        bridge.close()
        result["actions"].append("closed this process's loopback HTTP servers")
    container = inspect_resource(docker, "container", state["container_name"])
    if container is not None:
        assert container["labels"].get(LABEL) == lab_id
        assert not state.get("container_id") or container["id"] == state["container_id"]
        command(docker, ["stop", "--time", "20", container["id"]], instance, "stop-owned-container", timeout=40)
        command(docker, ["rm", container["id"]], instance, "remove-owned-container")
        result["actions"].append("stopped and removed exact labelled container")
    network = inspect_resource(docker, "network", state["network_name"])
    if network is not None:
        assert network["labels"].get(LABEL) == lab_id and network["state_or_internal"] is True
        assert not state.get("network_id") or network["id"] == state["network_id"]
        command(docker, ["network", "rm", network["id"]], instance, "remove-owned-network")
        result["actions"].append("removed exact labelled internal network")
    result.update(completed_at=now(), container_absent=inspect_resource(docker, "container", state["container_name"]) is None,
                  network_absent=inspect_resource(docker, "network", state["network_name"]) is None,
                  loopback_ports_closed=all(not port_open(p) for p in state.get("host_ports", [])))
    result["all_cleaned"] = result["container_absent"] and result["network_absent"] and result["loopback_ports_closed"]
    private_json(instance / "cleanup.json", result)
    return result


def wait_ready(n8n_url, state_url, timeout=180):
    until = time.monotonic() + timeout
    while time.monotonic() < until:
        try:
            code, health = call_json(n8n_url + "/healthz", timeout=2)
            crm_code, crm_health = call_json(state_url + "/health", timeout=2)
            settings_code, settings = call_json(n8n_url + "/rest/settings", timeout=2)
            user_management = (settings or {}).get("data", {}).get("userManagement")
            if code == crm_code == settings_code == 200 and crm_health.get("ok") and isinstance(user_management, dict):
                return {"ready_at": now(), "n8n_health": health, "state_health": crm_health,
                        "public_settings_json_ready": True,
                        "show_setup_on_first_load": user_management.get("showSetupOnFirstLoad")}
        except Exception:
            time.sleep(0.5)
    raise RuntimeError("This isolated instance did not become ready within180seconds")


def fresh_instance(path):
    if path is None:
        instance = Path(tempfile.mkdtemp(prefix="n8n-review-lab-")).resolve()
    else:
        instance = Path(path).expanduser().resolve()
        if instance == PACKAGE or PACKAGE in instance.parents:
            raise RuntimeError("Choose a fresh state directory outside the package")
        instance.mkdir(mode=0o700, parents=True, exist_ok=False)
    instance.chmod(0o700)
    for name in ["state", "runtime", "logs", "results"]:
        (instance / name).mkdir()
        # The image's non-root node user writes only these dedicated bind mounts.
        (instance / name).chmod(0o777 if name in ["state", "runtime", "logs"] else 0o700)
    return instance


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state-dir", help="New private instance directory, outside this package")
    parser.add_argument("--keep", action="store_true", help="After ten cases, keep fresh UI documents open until Ctrl-C")
    parser.add_argument("--ui-only", action="store_true", help="Start fresh UI documents without the automated suite; keep until Ctrl-C")
    parser.add_argument("--cleanup", metavar="INSTANCE_DIR", help="Clean a previous stopped runner's exact labelled resources")
    args = parser.parse_args()
    docker = shutil.which("docker")
    if not docker:
        parser.error("Docker is required on PATH")
    if args.cleanup:
        if args.state_dir or args.keep or args.ui_only:
            parser.error("--cleanup is a separate operation")
        instance = Path(args.cleanup).expanduser().resolve()
        state = json.loads((instance / "instance.json").read_text())
        if state.get("runner_pid") != os.getpid():
            try:
                os.kill(state["runner_pid"], 0)
            except ProcessLookupError:
                pass
            else:
                parser.error("Original runner is still alive; use Ctrl-C in its terminal first")
        result = cleanup(docker, instance, state)
        print(json.dumps({"cleanup_passed": result["all_cleaned"]}))
        return 0 if result["all_cleaned"] else 1
    instance = fresh_instance(args.state_dir)
    lab_id = "n8n-review-lab-" + secrets.token_hex(6)
    state = {"lab_id": lab_id, "container_name": lab_id + "-n8n", "network_name": lab_id + "-internal",
             "runner_pid": os.getpid(), "created_at": now(), "image": IMAGE, "host_ports": []}
    private_json(instance / "instance.json", state)
    bridge = None
    exit_code = 1
    try:
        # Inspect only the fixed public image; no existing container/config/volume is read.
        image_info = command(docker, ["image", "inspect", "--format", "{{json .Architecture}}\n{{json .Os}}\n{{json .RepoDigests}}", IMAGE],
                             instance, "image-preflight", allow_failure=True)
        if image_info.returncode:
            command(docker, ["pull", "--platform", "linux/arm64", IMAGE], instance, "pull-fixed-image", timeout=600)
            image_info = command(docker, ["image", "inspect", "--format", "{{json .Architecture}}\n{{json .Os}}\n{{json .RepoDigests}}", IMAGE],
                                 instance, "image-after-pull")
        architecture, operating_system, digests = [json.loads(line) for line in image_info.stdout.decode().splitlines()]
        assert architecture == "arm64" and operating_system == "linux" and IMAGE in digests
        private_json(instance / "image.json", {"image": IMAGE, "architecture": architecture, "os": operating_system, "repo_digests": digests})
        bridge = LoopbackBridge(docker, state["container_name"], 0, 0)
        bridge.start()
        n8n_port, state_port = [server.server_address[1] for server in bridge.servers]
        state.update(n8n_url="http://127.0.0.1:" + str(n8n_port), state_url="http://127.0.0.1:" + str(state_port),
                     host_ports=[n8n_port, state_port])
        private_json(instance / "instance.json", state)
        env = {
            "N8N_PORT": "5678", "N8N_HOST": "127.0.0.1", "N8N_LISTEN_ADDRESS": "0.0.0.0", "N8N_PROTOCOL": "http",
            "WEBHOOK_URL": state["n8n_url"] + "/", "N8N_EDITOR_BASE_URL": state["n8n_url"],
            "N8N_USER_FOLDER": "/lab/runtime", "DB_TYPE": "sqlite", "DB_SQLITE_DATABASE": "/lab/runtime/database.sqlite",
            "N8N_ENCRYPTION_KEY": secrets.token_hex(32), "N8N_DIAGNOSTICS_ENABLED": "false",
            "N8N_VERSION_NOTIFICATIONS_ENABLED": "false", "N8N_PERSONALIZATION_ENABLED": "false",
            "N8N_TEMPLATES_ENABLED": "false", "N8N_HIRING_BANNER_ENABLED": "false", "N8N_LICENSE_AUTO_RENEW_ENABLED": "false",
            "N8N_COMMUNITY_PACKAGES_ENABLED": "false", "N8N_PUBLIC_API_DISABLED": "true", "N8N_SECURE_COOKIE": "false",
            "N8N_BLOCK_ENV_ACCESS_IN_NODE": "true", "N8N_ENFORCE_SETTINGS_FILE_PERMISSIONS": "true",
            "EXECUTIONS_DATA_PRUNE": "false", "EXECUTIONS_DATA_SAVE_ON_SUCCESS": "all", "EXECUTIONS_DATA_SAVE_ON_ERROR": "all",
            "GENERIC_TIMEZONE": "UTC", "TZ": "UTC", "NODE_OPTIONS": "--max-old-space-size=1536",
            "LAB_STATE_DIR": "/lab/state", "LAB_N8N_PUBLIC_URL": state["n8n_url"] + "/",
        }
        env_path = instance / "private-container.env"
        fd = os.open(str(env_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as handle:
            handle.write("\n".join(k + "=" + v for k, v in env.items()) + "\n")
        network = command(docker, ["network", "create", "--internal", "--label", LABEL + "=" + lab_id, state["network_name"]],
                          instance, "create-network")
        state["network_id"] = network.stdout.decode().strip()
        private_json(instance / "instance.json", state)
        container_args = ["run", "-d", "--pull=never", "--platform", "linux/arm64", "--name", state["container_name"],
                          "--network", state["network_name"], "--label", LABEL + "=" + lab_id,
                          "--security-opt", "no-new-privileges", "--cap-drop", "ALL", "--pids-limit", "256", "--memory", "2g", "--cpus", "2",
                          "--env-file", str(env_path)]
        for name in ["review-services.mjs", "http-bridge.mjs", "workflows.json", "start-server.sh"]:
            container_args += ["-v", str(PACKAGE / name) + ":/lab/" + name + ":ro"]
        for name in ["state", "runtime", "logs"]:
            container_args += ["-v", str(instance / name) + ":/lab/" + name]
        container_args += ["--entrypoint", "/bin/sh", IMAGE, "/lab/start-server.sh"]
        container = command(docker, container_args, instance, "create-container")
        state["container_id"] = container.stdout.decode().strip()
        private_json(instance / "instance.json", state)
        assert inspect_resource(docker, "network", state["network_name"])["state_or_internal"] is True
        private_json(instance / "ready.json", wait_ready(state["n8n_url"], state["state_url"]))
        owner = {"email": "lab-" + secrets.token_hex(6) + "@example.invalid", "firstName": "Synthetic", "lastName": "Owner",
                 "password": "N8nLab-" + secrets.token_urlsafe(32) + "1!"}
        private_json(instance / "private-owner.json", owner)
        owner_status, _ = call_json(state["n8n_url"] + "/rest/owner/setup", owner, timeout=30)
        private_json(instance / "owner-setup.json", {"completed_at": now(), "status": owner_status, "credentials_printed": False})
        assert owner_status in [200, 201, 204]
        _, settings = call_json(state["n8n_url"] + "/rest/settings")
        assert settings["data"]["userManagement"]["showSetupOnFirstLoad"] is False
        for label, cli_args in [
            ("import-workflows", ["n8n", "import:workflow", "--input=/lab/workflows.json"]),
            ("publish-guarded", ["n8n", "publish:workflow", "--id=T20GuardedLab0001"]),
            ("publish-baseline", ["n8n", "publish:workflow", "--id=T20BaselineLab001"]),
        ]:
            command(docker, ["exec", state["container_name"], *cli_args], instance, label)
        command(docker, ["restart", "--time", "20", state["container_name"]], instance, "restart-own-container", timeout=45)
        private_json(instance / "published-ready.json", wait_ready(state["n8n_url"], state["state_url"]))
        node_version = command(docker, ["exec", state["container_name"], "node", "--version"], instance, "actual-node-version").stdout.decode().strip()
        n8n_version = command(docker, ["exec", state["container_name"], "n8n", "--version"], instance, "actual-n8n-version").stdout.decode().strip()
        private_json(instance / "versions.json", {"image": IMAGE, "node": node_version, "n8n": n8n_version})
        assert n8n_version == "2.49.6"
        inputs = json.loads((PACKAGE / "synthetic-inputs.json").read_text())
        client = LabClient(state["n8n_url"], state["state_url"], instance / "results", inputs)
        if not args.ui_only:
            summary = run_suite(client)
            print(json.dumps({"all_passed": summary["all_passed"], "case_count": summary["case_count"],
                              "request_count": summary["request_count"]}, ensure_ascii=False))
            if not summary["all_passed"]:
                raise RuntimeError("Some synthetic cases failed; inspect this instance's results.json")
        exit_code = 0
        print("Private instance evidence: " + str(instance), flush=True)
        if args.keep or args.ui_only:
            links = {}
            for mode in ["baseline", "guarded"]:
                doc = "ui-" + mode
                status, _ = call_json(state["state_url"] + "/lab/create", {"id": doc, "payload": inputs["original"]})
                assert status == 201
                links[mode] = {"review": state["n8n_url"] + "/webhook/review-" + mode + "?doc=" + doc,
                               "state": state["state_url"] + "/lab/state?doc=" + doc}
            private_json(instance / "ui-links.json", links)
            print(json.dumps({"ui_links": links, "owner_credentials": "private-owner.json in the private instance directory",
                              "stop": "Ctrl-C cleans only this run's container, internal network and loopback proxy"}, ensure_ascii=False), flush=True)
            while True:
                time.sleep(1)
    except KeyboardInterrupt:
        print("Stopping this lab's resources.", flush=True)
    except Exception as error:
        private_json(instance / "failure.json", {"failed_at": now(), "type": type(error).__name__, "message": str(error)})
        print("Lab failed; private evidence: " + str(instance), file=sys.stderr, flush=True)
        exit_code = 1
    finally:
        try:
            result = cleanup(docker, instance, state, bridge)
            print(json.dumps({"cleanup_passed": result["all_cleaned"]}), flush=True)
            if not result["all_cleaned"]:
                exit_code = 1
        except Exception as error:
            private_json(instance / "cleanup-failure.json", {"at": now(), "type": type(error).__name__, "message": str(error)})
            print("Cleanup needs review; use the exact private instance manifest, never a global prune.", file=sys.stderr)
            exit_code = 1
    return exit_code


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    raise SystemExit(main())
