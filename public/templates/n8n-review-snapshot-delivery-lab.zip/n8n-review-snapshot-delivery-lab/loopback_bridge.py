"""Loopback HTTP transport to this lab's container; preserves actual n8n bytes."""
import base64
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import subprocess
import threading


class LoopbackBridge:
    def __init__(self, docker, container, n8n_port, state_port):
        self.docker = docker
        self.container = container
        self.servers = []
        self.threads = []
        bridge = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def forward(self):
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    if not 0 <= length <= 1024 * 1024:
                        self.send_error(413)
                        return
                    body = self.rfile.read(length)
                    request = {
                        "port": self.server.internal_port,
                        "path": self.path,
                        "method": self.command,
                        "headers": {k.lower(): v for k, v in self.headers.items()},
                        "body": base64.b64encode(body).decode(),
                    }
                    process = subprocess.run(
                        [bridge.docker, "exec", "-i", bridge.container, "node", "/lab/http-bridge.mjs"],
                        input=json.dumps(request).encode(), capture_output=True, timeout=35,
                    )
                    if process.returncode:
                        raise RuntimeError("container HTTP bridge failed")
                    response = json.loads(process.stdout)
                    payload = base64.b64decode(response["body"])
                    self.send_response(response["status"])
                    skip = {"connection", "keep-alive", "transfer-encoding", "content-length",
                            "proxy-authenticate", "proxy-authorization", "te", "trailer", "upgrade"}
                    for i in range(0, len(response["headers"]), 2):
                        name, value = response["headers"][i:i + 2]
                        if name.lower() not in skip:
                            self.send_header(name, value)
                    self.send_header("Content-Length", str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                except (BrokenPipeError, ConnectionResetError):
                    return
                except Exception:
                    payload = b'{"error":"local_transport_failure"}'
                    self.send_response(502)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)

            do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = do_OPTIONS = forward

            def log_message(self, *args):
                # Owner setup/cookies and form inputs are never printed here.
                pass

        for host_port, internal_port in [(n8n_port, 5678), (state_port, 18082)]:
            server = ThreadingHTTPServer(("127.0.0.1", host_port), Handler)
            server.internal_port = internal_port
            server.daemon_threads = True
            self.servers.append(server)

    def start(self):
        for server in self.servers:
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            self.threads.append(thread)

    def close(self):
        for server in self.servers:
            server.shutdown()
            server.server_close()
        for thread in self.threads:
            thread.join(timeout=2)
